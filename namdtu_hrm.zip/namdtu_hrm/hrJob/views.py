from django.views.generic import ListView,TemplateView, DetailView 
from django.views.generic.edit import CreateView, FormMixin
from django.shortcuts import render
from accounts.models import CustomUser
from .models import JobVacancy, Ariza, ArizaJavob, ArizaYuborishLog
from .forms import JobVacancyForm, ArizaForm, ArizaJavobForm, RoleSelectionForm
from django.urls import reverse_lazy, reverse
from django.contrib.auth.mixins import UserPassesTestMixin
from django.contrib.auth.decorators import login_required

import os
from django.conf import settings
from django.shortcuts import get_object_or_404, redirect

from django.core.mail import send_mail
from django.http import HttpResponse

from django.contrib import messages
from django.db.models import Q


class JobsPagesViews(TemplateView):
    template_name = 'job.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        request = self.request
        search_query = request.GET.get('q', '').strip().lower()
        jobs = JobVacancy.objects.all().order_by('-berilgan_vaqt')

        if search_query:
            words = search_query.split()
            filtered_jobs = []
            for job in jobs:
                # Har bir job obyektining display qiymatlarini olish
                manzil_display = job.get_manzil_display().lower()
                fakultet_display = job.get_fakultet_display().lower()
                ish_nomi_display = job.get_ish_nomi_display().lower()

                # Agar qidiruvdagi har qanday so'z shu qiymatlarga to‘g‘ri kelsa — saqlaymiz
                for word in words:
                    if (word in manzil_display or
                        word in fakultet_display or
                        word in ish_nomi_display):
                        filtered_jobs.append(job)
                        break  # bitta so‘z mos bo‘lsa, ushbu ishni listga qo‘shamiz

            context['jobs'] = filtered_jobs
        else:
            context['jobs'] = jobs

        context['q'] = search_query
        return context
    
    
class VakansiyaYaratishView(UserPassesTestMixin, CreateView):
    model = JobVacancy
    form_class = JobVacancyForm
    template_name = 'vakansiya.html'
    success_url = reverse_lazy('jobs')

    def test_func(self):
        return self.request.user.is_superuser  # faqat admin
    

class VakansiyaDetailView(FormMixin, DetailView):
    model = JobVacancy
    template_name = 'vakansiya_detail.html'
    context_object_name = 'job'
    form_class = ArizaForm

    def get_success_url(self):
        return reverse('vakansiya_detail', kwargs={'pk': self.object.pk})

    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        form = self.get_form()
        if form.is_valid():
            ariza = form.save(commit=False)
            ariza.vakansiya = self.object
            ariza.user = request.user  # <-- SHU QATOR MUAMMONI HAL QILADI
            ariza.save()
            return self.form_valid(form)
        else:
            return self.form_invalid(form)



def ariza_list(request):
    search_query = request.GET.get('q', '').strip()
    arizalar = Ariza.objects.select_related('vakansiya').order_by('-yuborilgan_vaqt')
    
    if search_query:
        words = search_query.lower().split()
        query = Q()
        for word in words:
            query |= Q(ism__icontains=word)
            query |= Q(email__icontains=word)
            query |= Q(telefon__icontains=word)
        arizalar = arizalar.filter(query)
        
    return render(request, 'ariza_list.html', {'arizalar': arizalar,'q':search_query})

def ariza_delete(request, pk):
    ariza = get_object_or_404(Ariza, pk=pk)
    
    # Faylni fizik diskdan o‘chirish
    if ariza.rezyume and os.path.isfile(ariza.rezyume.path):
        os.remove(ariza.rezyume.path)

    # Bazadan yozuvni o‘chirish
    ariza.delete()
    return redirect('ariza_list')


def ariza_message(request, pk):
    ariza = get_object_or_404(Ariza, pk=pk)
    try:
        javob = ariza.arizajavob
    except ArizaJavob.DoesNotExist:
        javob = None

    if request.method == 'POST':
        form = ArizaJavobForm(request.POST, instance=javob)
        if form.is_valid():
            javob = form.save(commit=False)
            javob.ariza = ariza
            javob.from_user = request.user  # admin
            javob.save()
            
            email = ariza.email
            print(f"📧 Yuborilayotgan email: {email}")

            try:
                send_mail(
                    subject='Arizangiz haqida',
                    message='Siz yuborgan ariza ko‘rib chiqildi.',
                    from_email='ergashevsamandar0394@gmail.com',
                    recipient_list=[email],
                    fail_silently=False,
                )
                return redirect('ariza_list')
            except Exception as e:
                return HttpResponse(f"❌ Email yuborishda xatolik: {str(e)}")
            
    else:
        form = ArizaJavobForm(instance=javob)

    return render(request, 'message.html', {'form': form, 'ariza': ariza})

@login_required
def foydalanuvchi_message(request):
    xabarlar = ArizaJavob.objects.filter(ariza__user=request.user)
    return render(request, 'foydalanuvchiMessage.html', {'messages': xabarlar})


# from django.http import HttpResponse
# from django.core.mail import send_mail

# def test_email(request):
#     try:
#         send_mail(
#             subject='Test Email',
#             message='Bu test emailidir',
#             from_email='ergashevsamandar0394@gmail.com',
#             recipient_list=['samandarergashev2725@gmail.com'],  # o'zingizning Gmail manzilingizni yozing
#             fail_silently=False,
#         )
#         return HttpResponse("Email muvaffaqiyatli yuborildi!")
#     except Exception as e:
#         return HttpResponse(f"Xatolik: {str(e)}")


def ariza_send(request, pk):
    ariza = get_object_or_404(Ariza, id=pk)

    if request.method == 'POST':
        form = RoleSelectionForm(request.POST)
        if form.is_valid():
            selected_roles = form.cleaned_data['selected_roles']
            
            # Ushbu rollarga ega foydalanuvchilarni topamiz
            users_to_send = CustomUser.objects.filter(role__in=selected_roles)

            # Har bir foydalanuvchiga ariza yuborilganligini logga yozamiz
            for user in users_to_send:
                ArizaYuborishLog.objects.create(ariza=ariza, kimga=user.role)

            messages.success(request, f"{len(users_to_send)} ta foydalanuvchiga ariza yuborildi.")
            return redirect('ariza_list')  # Yoki kerakli sahifaga
    else:
        form = RoleSelectionForm()

    return render(request, 'applicationMessage.html', {'form': form, 'ariza': ariza})


@login_required
def roleArizaMessage(request):
    user_role = request.user.role  # foydalanuvchining roli
    yuborilgan_arizalar = ArizaYuborishLog.objects.filter(kimga=user_role).order_by('-yuborilgan_vaqt')
    
    context = {
        'yuborilgan_arizalar': yuborilgan_arizalar
    }
    return render(request, 'roleArizaMessage.html', context)



from django.views.decorators.http import require_POST

@require_POST
@login_required
def ariza_javob_berish(request, log_id):
    log = get_object_or_404(ArizaYuborishLog, id=log_id)

    if log.kimga != request.user.role:
        messages.error(request, "Siz bu arizaga javob bera olmaysiz.")
        return redirect('role_ariza_messages')

    javob = request.POST.get('javob')

    if javob == 'qabul':
        log.holat = True
    elif javob == 'rad':
        log.holat = False
    else:
        messages.error(request, "Noto‘g‘ri amal.")
        return redirect('role_ariza_messages')

    log.javob_berilgan = True
    log.save()

    # Adminlarga xabar berish yoki ko‘rsatish uchun siz keyincha email yoki log oynasi qo‘shishingiz mumkin
    messages.success(request, "Javob muvaffaqiyatli yuborildi.")
    return redirect('role_ariza_messages')

from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Prefetch

@staff_member_required
def ariza_javoblar_admin(request):
    # Faqat javob berilgan arizalar
    loglar = ArizaYuborishLog.objects.filter(javob_berilgan=True).select_related('ariza__vakansiya')

    # Vakansiya bo‘yicha guruhlab olish uchun dict tayyorlaymiz
    guruhlangan = {}

    for log in loglar:
        vakansiya_nomi = log.ariza.vakansiya.get_ish_nomi_display()
        if vakansiya_nomi not in guruhlangan:
            guruhlangan[vakansiya_nomi] = []
        guruhlangan[vakansiya_nomi].append(log)

    return render(request, 'admin_ariza_javoblar.html', {'guruhlangan': guruhlangan})

@login_required
def mening_arizalarim(request):
    arizalar = Ariza.objects.filter(user=request.user).select_related('vakansiya')
    return render(request, 'mening_arizalarim.html', {'arizalar': arizalar})