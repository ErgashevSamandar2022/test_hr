from django.db import models
from django.contrib.auth import get_user_model
User = get_user_model()

class JobVacancy(models.Model):
    MANZIL_CHOICES = [
        ('bino1', 'Namangan Davlat Texnika Universiteti 1-O\'quv bino'),
        ('bino2', 'Namangan Davlat Texnika Universiteti 2-O\'quv bino'),
        # Hohlagancha qo‘shish mumkin
    ]
    ISH_TURI_CHOICES=[
        ("toliq","To‘liq stavka"),
        ("yarim","Yarim stavka"),
        ("stajirovka","Stajirovka"),
        ("vaqtinchalik","Vaqtinchalik"),
        ("amaloyotchi","Amaloyotchi"),
    ]

    ISH_TAJRIBASI_CHOICES = [
        ('1yil', 'Kamida 1 yillik staj'),
        ('2yil', 'Kamida 2 yillik staj'),
        ('3yil', 'Kamida 3 yillik staj'),
        ('4yil', 'Kamida 4 yillik staj'),
        ('5yil_plus', 'Kamida 5+ yillik staj'),
        ('no_staj', 'Mehnat staji talab etilmaydi'),
    ]
    
    FAKULTET_CHOICES = [
        ('muhandislik','Muhandislik-axborot texnologiyalari'),
        ('transport','Transport'),
        ('biznesni','Biznesni boshqarish'),
        ('iqtisodiyot','Iqtisodiyot'),
        ('qurilish','Qurilish'),
        ('texnologiya','Texnologiya'),
        ('energetika','Energetika'),
        ('mexanika','Mexanika'),
        ('toqimachilik','To‘qimachilik sanoati injineringi'),
        ('boshqa','Boshqa sohada'),
    ]
    
    ISHNOMI_CHOICES = [
        ('oqituvchi', "O'qituvchi"),
        ('katta_oqituvchi', "Katta o'qituvchi"),
        ('dotsent', 'Dotsent'),
        ('professor', 'Professor'),
        ('stajyor_oqituvchi', "Stajyor-o'qituvchi"),
        ('laborator', 'Laboratoriya xodimi'),
        ('dekan', 'Dekan'),
        ('kafedra_mudiri', 'Kafedra mudiri'),
        ('ilmiy_kotib', 'Ilmiy kotib'),
        ('yoshlar_mutaxassis', "Yoshlar masalalari bo'yicha mutaxassis"),
        ('hr_xodim', "HR (kadrlar) bo'limi xodimi"),
        ('marketing_mutaxassis', "Marketing bo'limi mutaxassisi"),
        ('web_dasturchi', 'Dasturchi / web dasturchi'),
        ('it_texnik', 'IT texnik xodimi'),
        ('admin', 'Tizim administrator'),
        ('kutubxonachi', 'Kutubxonachi'),
        ('tozalash', 'Tozalash xodimi'),
        ('xojalik_xodim', "Xo'jalik ishlari bo'yicha xodim"),
    ]

    manzil = models.CharField(max_length=100, choices=MANZIL_CHOICES)
    fakultet = models.CharField(max_length=200,choices=FAKULTET_CHOICES)
    ish_nomi = models.CharField(max_length=200,choices=ISHNOMI_CHOICES)
    ish_tajribasi = models.CharField(max_length=150,choices=ISH_TAJRIBASI_CHOICES)
    ish_turi = models.CharField(max_length=100, choices=ISH_TURI_CHOICES)
    oylik = models.DecimalField(max_digits=10, decimal_places=2)
    vakansiya_tugash_vaqti = models.DateField()
    berilgan_vaqt = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ish_nomi} ({self.manzil})"
    
class Ariza(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    vakansiya = models.ForeignKey('JobVacancy', on_delete=models.CASCADE)
    ism = models.CharField(max_length=100)
    telefon = models.CharField(max_length=20)
    email = models.EmailField()
    rezyume = models.FileField(upload_to='rezyumelar/')
    yuborilgan_vaqt = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.ism} - {self.vakansiya.ish_nomi}"


class ArizaJavob(models.Model):
    ariza = models.OneToOneField(Ariza, on_delete=models.CASCADE, related_name='arizajavob')
    xabar = models.TextField()
    yuborilgan_vaqt = models.DateTimeField(auto_now_add=True)
    from_user = models.ForeignKey(get_user_model(), related_name='sent_messages', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Xabar: {self.ariza.ism}"

    
class ArizaYuborishLog(models.Model):
    ariza = models.ForeignKey('Ariza', on_delete=models.CASCADE)
    kimga = models.CharField(max_length=100)
    yuborilgan_vaqt = models.DateTimeField(auto_now_add=True)
    holat = models.BooleanField(null=True, blank=True)  # True=Qabul, False=Rad, None=javob berilmagan
    javob_berilgan = models.BooleanField(default=False)  # Admin ko‘rishi uchun

    def __str__(self):
        return f"{self.ariza} -> {self.kimga}"
