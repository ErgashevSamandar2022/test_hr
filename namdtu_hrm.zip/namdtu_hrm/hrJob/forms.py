from django import forms
from .models import JobVacancy, Ariza, ArizaJavob

class JobVacancyForm(forms.ModelForm):
    class Meta:
        model = JobVacancy
        fields = '__all__'
        widgets = {
            'vakansiya_tugash_vaqti': forms.DateInput(attrs={'type': 'date'}),
        }
class ArizaForm(forms.ModelForm):
    class Meta:
        model = Ariza
        fields = ['ism', 'telefon', 'email', 'rezyume']
        
class ArizaJavobForm(forms.ModelForm):
    class Meta:
        model = ArizaJavob
        fields = ['xabar']

ROLES = (
        ('muhamdislikDekan', 'Muahdislik Fakulteti Dekani'),
        ('muhamdislikMudir', 'Muhandislik Fakulteti Mudiri'),
        ('transportDekan', 'Taransport Fakulteti Dekani'),
        ('transportMudir', 'Transport Fakulteti Mudiri'),
        ('biznesDekan', 'Biznesni boshqarish Fakulteti Dekani'),
        ('biznesMudir', 'Biznesni boshqarish Fakulteti Mudiri'),
        ('iqtisodiyotDekan', 'Iqtisoqiyot Fakulteti Dekani'),
        ('iqtisodiyotMudir', 'Iqtisodiyot Fakulteti Mudiri'),
        ('qurilishDekan', 'Qurilish Fakulteti Dekani'),
        ('qurilishMudir', 'Qurilish Fakulteti Mudiri'),
        ('texnologiyaDekan', 'Texnologiya Fakulteti Dekani'),
        ('texnologiyaMudir', 'Texnologiya Fakulteti Mudiri'),
        ('energetikaDekan', 'Energetika Fakulteti Dekani'),
        ('energetikaMudir', 'Energetika Fakulteti Mudiri'),
        ('mehanikaDekan', 'Mehanika Fakulteti Dekani'),
        ('mehanikaMudir', 'Mexanika Fakulteti Mudiri'),
        ('toqimaDekan', 'To\'qimachilik Fakulteti Dekani'),
        ('toqimaMudir', 'To\'qimachilik Fakulteti Mudiri'),
        ('oquvProrektor', 'O\'quv ishlar bo\'yicha Prorektor'),
        ('ilmiyProrektor', 'Ilmiy ishlar bo\'yicha Prorektor'),
        ('rektor', 'Rektor'),
        ('kutubxonachi', 'Kutubxona Mudiri'),
        ('texnikXizmat', 'Texnik xizmat ko\'rsatish hodimi'),
        ('xizmatKorsatish', 'Xizmat ko\'rsatish hodimi'),
        ('admin', 'Administrator'),
    )


# class ArizaYuborishForm(forms.Form):
#     rollar = forms.MultipleChoiceField(
#         choices=ROLES,
#         widget=forms.CheckboxSelectMultiple,
#         required=False
#     )
    
class RoleSelectionForm(forms.Form):
    selected_roles = forms.MultipleChoiceField(
        choices=ROLES,
        widget=forms.CheckboxSelectMultiple,
        required=True,
        label="Kimlarga yuborilsin?"
    )