from django.urls import path
from .views import (
    JobsPagesViews, 
    VakansiyaYaratishView,
    VakansiyaDetailView, 
    ariza_list, 
    ariza_delete, 
    ariza_message, 
    ariza_send, 
    foydalanuvchi_message, 
    roleArizaMessage, 
    ariza_javob_berish, 
    ariza_javoblar_admin, 
    mening_arizalarim )

urlpatterns = [
    path('vakansiyalar/', JobsPagesViews.as_view(), name='jobs'),
    path('vakansiya-qoshish/', VakansiyaYaratishView.as_view(), name='create_job'),
    
    path('vakansiya/<int:pk>/', VakansiyaDetailView.as_view(), name='vakansiya_detail'),
    
    path('arizalar/', ariza_list, name='ariza_list'),
    path('ariza/<int:pk>/delete/', ariza_delete, name='ariza_delete'),
    path('ariza/<int:pk>/message/', ariza_message, name='ariza_message'),
    path('ariza/<int:pk>/send/', ariza_send, name='ariza_send'),
    
    
    path('foydalanuvchi/messages/', foydalanuvchi_message, name='foydalanuvchi_message'),
    path('role-ariza-messages/', roleArizaMessage, name='role_ariza_messages'),
    path('ariza_javob/<int:log_id>/', ariza_javob_berish, name='ariza_javob_berish'),
    path('admin/ariza-jadval/', ariza_javoblar_admin, name='admin_ariza_jadval'),
    path('mening-arizalarim/', mening_arizalarim, name='mening_arizalarim'),
    
    # path('test-email/', test_email, name='test_email'),
]
