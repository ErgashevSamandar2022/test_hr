from django.contrib import admin
from .models import JobVacancy, Ariza, ArizaJavob

@admin.register(JobVacancy)
class JobVacancyAdmin(admin.ModelAdmin):
    list_display = ('ish_nomi', 'manzil', 'fakultet', 'ish_turi', 'oylik', 'berilgan_vaqt', 'vakansiya_tugash_vaqti')
    search_fields = ('ish_nomi', 'fakultet', 'manzil')
    list_filter = ('ish_turi', 'manzil', 'fakultet')

admin.site.register(Ariza)
@admin.register(ArizaJavob)
class ArizaJavobAdmin(admin.ModelAdmin):
    list_display = ('ariza', 'from_user', 'created_at')
    list_filter = ('from_user',)
    search_fields = ('ariza__ism', 'xabar')