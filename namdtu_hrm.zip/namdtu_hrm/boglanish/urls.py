from django.urls import path
from .views import ContactViewsPage

urlpatterns = [
		path('boglanish',ContactViewsPage.as_view(), name='contact')
]
