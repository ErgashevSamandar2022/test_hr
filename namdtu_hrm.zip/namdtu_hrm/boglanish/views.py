# contact/views.py
from django.views.generic.edit import FormView
from .forms import ContactForm
from django.urls import reverse_lazy

class ContactViewsPage(FormView):
    template_name = "boglanish.html"
    form_class = ContactForm
    success_url = reverse_lazy('contact')  # Yuborilgandan keyin o‘sha sahifaga qaytadi

    def form_valid(self, form):
      form.save()
      self.request.session['submitted'] = True
      return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
      context = super().get_context_data(**kwargs)
      context['submitted'] = self.request.session.pop('submitted', False)
      return context


