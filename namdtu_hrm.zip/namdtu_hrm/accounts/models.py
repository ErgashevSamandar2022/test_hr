from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db.models.signals import post_save
from django.dispatch import receiver

class CustomUser(AbstractUser):
    phone = models.CharField(
        max_length=20,
        blank=True,
        null=True,
        verbose_name="Telefon raqam"
    )
    ROLE_CHOICES = (
        ('user', 'Foydalanuvchi'),
        ('muhamdislikDekan', 'Muahdislik Fakulteti Dekani'),
        ('muhamdislikMudir', 'Muhandislik Fakulteti Mudiri'),
        ('transportDekan', 'Taransport Fakulteti Dekani'),
        ('transportMudir', 'Transport Fakulteti Mudiri'),
        ('biznesDekan', 'Biznesni boshqarish Fakulteti Dekani'),
        ('biznesMudir', 'Biznesni boshqarish Fakulteti Mudiri'),
        ('iqtisodiyotDekan', 'Iqtisoqiyot Fakulteti Dekani'),
        ('iqtisodiyotMudir', 'Iqtisodiyot Fakulteti Mudiri'),
        ('qurilishDekan', 'Qurilish Fakulteti Dekani'),
        ('qurilishMudir', 'Qurilish Fakulteti Mudiri'),
        ('texnologiyaDekan', 'Texnologiya Fakulteti Dekani'),
        ('texnologiyaMudir', 'Texnologiya Fakulteti Mudiri'),
        ('energetikaDekan', 'Energetika Fakulteti Dekani'),
        ('energetikaMudir', 'Energetika Fakulteti Mudiri'),
        ('mehanikaDekan', 'Mehanika Fakulteti Dekani'),
        ('mehanikaMudir', 'Mexanika Fakulteti Mudiri'),
        ('toqimaDekan', 'To\'qimachilik Fakulteti Dekani'),
        ('toqimaMudir', 'To\'qimachilik Fakulteti Mudiri'),
        ('oquvProrektor', 'O\'quv ishlar bo\'yicha Prorektor'),
        ('ilmiyProrektor', 'Ilmiy ishlar bo\'yicha Prorektor'),
        ('rektor', 'Rektor'),
        ('kutubxonachi', 'Kutubxona Mudiri'),
        ('texnikXizmat', 'Texnik xizmat ko\'rsatish hodimi'),
        ('xizmatKorsatish', 'Xizmat ko\'rsatish hodimi'),
        ('admin', 'Administrator'),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='user')
    is_approved = models.BooleanField(default=False)

    def __str__(self):
        return self.username

@receiver(post_save, sender=CustomUser)
def set_default_role(sender, instance, created, **kwargs):
    if created:
        instance.role = 'user'
        instance.save()