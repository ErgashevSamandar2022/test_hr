from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import CustomUserCreationForm
from .models import CustomUser
from django.contrib.auth.mixins import UserPassesTestMixin
from django.views import View
from django.db.models import Q

def signup(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.role = 'user'  # Barcha yangi foydalanuvchilar uchun standart rol
            user.save()
            login(request, user)
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

class FoydalanuvchiPagesViews(UserPassesTestMixin, View):
    template_name = 'user_list.html'

    def test_func(self):
        return self.request.user.is_superuser or self.request.user.is_staff # Faqat adminlar kirishi mumkin
    
    def get(self, request):
        search_query = request.GET.get('q', '').strip()
        users = CustomUser.objects.all()

        if search_query:
            words = search_query.lower().split()
            query = Q()
            for word in words:
                query |= Q(username__icontains=word) | Q(email__icontains=word)
            users = users.filter(query)

        return render(request, self.template_name, {
            'users': users,
            'q': search_query
        })
        
    # def get(self, request):
    #     users = CustomUser.objects.all()  # Barcha foydalanuvchilarni olish
    #     return render(request, self.template_name, {'users': users})

    def post(self, request):
        user_id = request.POST.get('user_id')  # Foydalanuvchi ID'sini olish
        new_role = request.POST.get('new_role')  # Yangi rolni olish
        user = CustomUser.objects.get(id=user_id)  # Foydalanuvchini olish
        
        user.role = new_role  # Rolni yangilash
        
        # Agar foydalanuvchi admin yoki taqrizchi bo'lsa, is_approved True qilish
        if new_role in ['admin']:
            user.is_approved = True
        else:
            user.is_approved = False
        
        user.save()  # Foydalanuvchini saqlash

        return redirect('user_list')  # 'foydalanuvchilar' nomli sahifaga qaytish