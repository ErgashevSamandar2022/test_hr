from django.shortcuts import render
from django.views.generic import ListView,TemplateView
from hrJob.models import JobVacancy
# Create your views here.

class HomePagesViews(TemplateView):
    template_name = 'index.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # So‘nggi 8 ta vakansiyani saralab olish (berilgan_vaqt bo‘yicha)
        context['latest_jobs'] = JobVacancy.objects.all().order_by('-berilgan_vaqt')[:8]
        return context
    
class AboutPagesViews(TemplateView):
    template_name = 'about.html'