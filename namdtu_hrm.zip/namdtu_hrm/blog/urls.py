from django.urls import path
from .views import HomePagesViews,AboutPagesViews

urlpatterns = [
		path('',HomePagesViews.as_view(),name='home'),
		path('about/',AboutPagesViews.as_view(),name='about'),
]

